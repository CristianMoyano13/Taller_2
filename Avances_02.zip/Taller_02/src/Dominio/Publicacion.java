
public class Publicacion {

}
