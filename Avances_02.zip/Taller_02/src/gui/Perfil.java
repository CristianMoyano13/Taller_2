package gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JList;
import java.awt.Choice;
import java.awt.List;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.ScrollPane;

public class Perfil extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Perfil frame = new Perfil();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Perfil() {
		setTitle("VentasCoquimbo - Perfil");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 446, 394);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Bienvenido ");
		lblNewLabel.setBounds(38, 11, 55, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Lista de productos disponilbes");
		lblNewLabel_1.setBounds(48, 36, 151, 14);
		contentPane.add(lblNewLabel_1);
		
		List list = new List();
		list.setBounds(26, 56, 349, 196);
		contentPane.add(list);
		
		JButton btnNewButton = new JButton("Vender producto");
		btnNewButton.setBounds(38, 283, 113, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Mis Publicaciones");
		btnNewButton_1.setBounds(38, 317, 113, 23);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Info. Productos");
		btnNewButton_2.setBounds(175, 283, 113, 23);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Mis Compras");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_3.setBounds(175, 317, 113, 23);
		contentPane.add(btnNewButton_3);
		
		Choice Categoria = new Choice();
		Categoria.setBounds(312, 283, 75, 20);
		contentPane.add(Categoria);
		
		JButton btnNewButton_4 = new JButton("Filtrar");
		btnNewButton_4.setBounds(312, 317, 75, 23);
		contentPane.add(btnNewButton_4);
		
		JLabel lblNewLabel_2 = new JLabel("\"Nombre Usuario\"");
		lblNewLabel_2.setBounds(103, 11, 94, 14);
		contentPane.add(lblNewLabel_2);
	}
}
