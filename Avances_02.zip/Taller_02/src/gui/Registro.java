package gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Window.Type;
import javax.swing.JTextArea;
import javax.swing.JList;
import javax.swing.JScrollBar;

public class Registro extends JFrame {
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Registro frame = new Registro();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Registro() {
		setTitle("VentasCoquimbo - Reg\u00EDstro");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Nombre de usuario");
		lblNewLabel.setBounds(65, 40, 98, 14);
		getContentPane().add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(65, 58, 112, 20);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Correo");
		lblNewLabel_1.setBounds(65, 89, 46, 14);
		getContentPane().add(lblNewLabel_1);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(65, 107, 112, 20);
		getContentPane().add(textField_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Contrase\u00F1a");
		lblNewLabel_1_1.setBounds(65, 138, 98, 14);
		getContentPane().add(lblNewLabel_1_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(65, 156, 112, 20);
		getContentPane().add(textField_2);
		
		JLabel lblNombreCompleto = new JLabel("Nombre completo");
		lblNombreCompleto.setBounds(259, 40, 98, 14);
		getContentPane().add(lblNombreCompleto);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(259, 58, 112, 20);
		getContentPane().add(textField_3);
		
		JLabel lblNewLabel_1_2 = new JLabel("Contacto");
		lblNewLabel_1_2.setBounds(259, 89, 46, 14);
		getContentPane().add(lblNewLabel_1_2);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(259, 107, 112, 20);
		getContentPane().add(textField_4);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("Confirmar Contrase\u00F1a");
		lblNewLabel_1_1_1.setBounds(259, 138, 136, 14);
		getContentPane().add(lblNewLabel_1_1_1);
		
		textField_5 = new JTextField();
		textField_5.setColumns(10);
		textField_5.setBounds(259, 156, 112, 20);
		getContentPane().add(textField_5);
		
		JButton btnNewButton = new JButton("Reg\u00EDstrarse");
		btnNewButton.setBounds(173, 204, 89, 23);
		getContentPane().add(btnNewButton);
	}
}
