package L�gica;
public class ListaProductos {

}
