package L�gica;

import Dominio.Usuario;

public class ListaUsuarios {
	private Usuario[] listaUsuarios;
	private int cont;
	private int max;
	
	public ListaUsuarios(int max) {
		listaUsuarios = new Usuario[max];
		cont = 0;
		this.max=max;
	}
	public int posicionCliente(String nombre) {
        for (int i = 0; i <= cont; i++) {
            if (listaUsuarios[i].getNomUsuario().equals(nombre)) {
                return i;
            }
        }
		return -1;
	}
	public boolean insertarUsuario(Usuario usuario) { 
		if (cont < max) {
			listaUsuarios[cont] = usuario;
			cont++;
			return true;

		} else {
			return false;
		}
	}
	public boolean eliminarUsuario(Usuario usuario, int posicionUsuario) { 
		if (cont < max) {
			for(int i=posicionUsuario;i<cont;i++) {
				listaUsuarios[posicionUsuario] = listaUsuarios[i+1];
			}
			return true;
		} else {
			return false;
		}
	}
	public Usuario buscarNombre(String nombre) {
		int i;
		for (i = 0; i < cont; i++) {
			if (listaUsuarios[i].getNomUsuario().equals(nombre)) {
				break;
			}
		}
		if (i == cont) {
			return null;
		} 
		else {
			return listaUsuarios[i];
		}
	}
	public Usuario getUsuarioI(int i) {
		if (i >= 0 && i < cont) {
			return listaUsuarios[i];

		} else {
			return null;
		}
	}
	public Usuario[] getListaUsuarios() {
		return listaUsuarios;
	}
	public void setListaUsuarios(Usuario[] listaUsuarios) {
		this.listaUsuarios = listaUsuarios;
	}
	public int getCont() {
		return cont;
	}
	public void setCont(int cont) {
		this.cont = cont;
	}
	public int getMax() {
		return max;
	}
	public void setMax(int max) {
		this.max = max;
	}
}
