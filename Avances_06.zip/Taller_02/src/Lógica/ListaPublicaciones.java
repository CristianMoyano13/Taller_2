package L�gica;

import Dominio.NodoPublicaciones;
import Dominio.Publicacion;

public class ListaPublicaciones {

	private NodoPublicaciones primero;
		
		public ListaPublicaciones() {
			primero = null;
		}
		public void insertarPrimero(Publicacion p) {
			NodoPublicaciones newNodo = new NodoPublicaciones(p);
			newNodo.setSiguente(primero);
			primero = newNodo;
		}
		public boolean encontrar(int key) {
			NodoPublicaciones nodoActual = primero;
			while(nodoActual != null && nodoActual.getPublicacion().getId() != key) {
				nodoActual = nodoActual.getSiguente();
			}
			if(nodoActual != null) {
				return true;
			}
			else {
				return false;
			}
		}
		public boolean eliminar(int key) {
			NodoPublicaciones actual = primero;
			NodoPublicaciones previo = primero;
			while(actual != null && actual.getPublicacion().getId()!= key) {
				previo = actual;
				actual = actual.getSiguente();
			}
			if(actual != null) {
				if(actual == primero) {
					primero = primero.getSiguente();
				}
				else {
					previo.setSiguente(actual.getSiguente());
				}
				return true;
			}
			else {
				return false;
			}
		}
		public NodoPublicaciones getPrimero() {
			return primero;
		}
	

}
