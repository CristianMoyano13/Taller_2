package Dominio;

import java.io.File;

public class Publicacion {
	private String nombre;
	private int precio;
	private String descripcion;
	private String fecha;
	private int id;
	private String categoria;
	private File foto;
	
	public Publicacion(String nombre, int precio, String descripcion,int id,String fecha,String categoria, File foto) {
		this.nombre = nombre;
		this.precio = precio;
		this.descripcion = descripcion;
		this.id = id;
		this.fecha = fecha ;
		this.categoria = categoria;
		this.foto = foto;
		
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getPrecio() {
		return precio;
	}

	public void setPrecio(int precio) {
		this.precio = precio;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFecha() {
		return fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	public String getCategoria() {
		return categoria;
	}

	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}
	
	
	
	
}
