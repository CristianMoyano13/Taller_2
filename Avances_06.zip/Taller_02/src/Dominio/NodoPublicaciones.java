package Dominio;

public class NodoPublicaciones {

	private Publicacion publicacion;
	private NodoPublicaciones siguente;
	
	public NodoPublicaciones(Publicacion p) {
		this.publicacion = p;
		siguente = null;
	}

	public Publicacion getPublicacion() {
		return publicacion;
	}

	public void setPublicacion(Publicacion publicacion) {
		this.publicacion = publicacion;
	}

	public NodoPublicaciones getSiguente() {
		return siguente;
	}

	public void setSiguente(NodoPublicaciones s) {
		this.siguente = s;
	}
}
