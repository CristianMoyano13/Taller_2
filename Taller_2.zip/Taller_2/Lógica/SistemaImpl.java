

public class SistemaImpl implements Sistema {

	
}
