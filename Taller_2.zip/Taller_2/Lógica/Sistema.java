
public interface  Sistema {

}
