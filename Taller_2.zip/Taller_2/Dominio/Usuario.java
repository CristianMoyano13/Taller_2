
public class Usuario {

}
