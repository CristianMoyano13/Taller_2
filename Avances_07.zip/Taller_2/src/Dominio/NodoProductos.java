package Dominio;

public class NodoProductos {
	private Producto producto;
	private NodoProductos siguente;
	
	public NodoProductos(Producto p) {
		this.producto = p;
		siguente = null;
	}

	public Producto getProducto() {
		return producto;
	}

	public void setProducto(Producto producto) {
		this.producto = producto;
	}

	public NodoProductos getSiguente() {
		return siguente;
	}

	public void setSiguente(NodoProductos s) {
		siguente = s;
	}
	
}
