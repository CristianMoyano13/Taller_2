package Dominio;
public class Compras {
	private Usuario usuario;
	private Producto producto;
	public Compras(Usuario usuario, Producto producto) {
		this.usuario = usuario;
		this.producto = producto;
	}
	public Usuario getUsuario() {
		return usuario;
	}
	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}
	public Producto getProducto() {
		return producto;
	}
	public void setProducto(Producto producto) {
		this.producto = producto;
	}
}