package gui;
import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.AbstractListModel;
import javax.swing.JButton;
import java.awt.List;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
public class MisPublicaciones extends JFrame implements ActionListener {
	private JPanel contentPane;
	private JTable tablaPublicaciones;
	JButton BotonEditar, BotonBorrar;
	private DefaultTableModel model;
	public MisPublicaciones() {
		setTitle("VentasCoquimbo - Mis Publicaciones");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 423, 414);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Informaci�n personal");
		lblNewLabel.setBounds(38, 11, 185, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Nombre completo");
		lblNewLabel_1.setBounds(238, 11, 185, 14);
		contentPane.add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("Publicaciones");
		lblNewLabel_2.setBounds(138, 31, 185, 14);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Cantidad de ventas: ");
		lblNewLabel_3.setBounds(138, 331, 185, 14);
		contentPane.add(lblNewLabel_3);
		
		BotonEditar = new JButton("Editar Producto");
		BotonEditar.setBounds(26, 283, 139, 23);
		BotonEditar.addActionListener(this);
		contentPane.add(BotonEditar);
		
		BotonBorrar = new JButton("Borrar Producto");
		BotonBorrar.setBounds(226, 283, 139, 23);
		BotonBorrar.addActionListener(this);
		contentPane.add(BotonBorrar);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(26, 60, 361, 212);
		contentPane.add(scrollPane);
		tablaPublicaciones = new JTable();
		model = new DefaultTableModel();
		tablaPublicaciones.setModel(model);
		model.addColumn("ID");
		model.addColumn("Nombre");
		model.addColumn("Categor�a");
		model.addColumn("Fecha");
		model.addColumn("Vendidas (S/N)");
		scrollPane.setViewportView(tablaPublicaciones);	
	}
	public void actionPerformed(ActionEvent e) {
	}
}
