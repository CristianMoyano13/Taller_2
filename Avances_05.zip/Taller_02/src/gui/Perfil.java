package gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import L�gica.App;
import L�gica.ListaProductos;
import L�gica.ListaUsuarios;
import L�gica.SistemaVentasImpl;

import javax.swing.JLabel;
import javax.swing.JList;
import java.awt.Choice;
import java.awt.List;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import java.awt.ScrollPane;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JToolBar;
import javax.swing.JSlider;
import javax.swing.JMenuBar;
import javax.swing.table.DefaultTableModel;

import Dominio.NodoProductos;
import Dominio.Producto;

import java.awt.Color;
import javax.swing.AbstractListModel;
import javax.swing.JScrollBar;

public class Perfil extends javax.swing.JDialog implements ActionListener {
	
	public static String filtroElegido;
	private JPanel contentPane;	
	private JTable tablaProductos;
	JButton BotonVender,BotonPublicaciones,BotonInfo,BotonMisCompras,BotonFiltrar;
	private DefaultTableModel model;
	
	public Perfil() {
		setTitle("VentasCoquimbo - Perfil");
		setDefaultCloseOperation(HIDE_ON_CLOSE);
		setBounds(100, 100, 423, 414);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		JLabel lblNewLabel = new JLabel("Bienvenido ");
		lblNewLabel.setBounds(38, 11, 85, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Lista de productos disponilbes");
		lblNewLabel_1.setBounds(48, 36, 227, 14);
		contentPane.add(lblNewLabel_1);
		
		BotonVender = new JButton("Vender producto");
		BotonVender.setBounds(26, 283, 139, 23);
		BotonVender.addActionListener(this);
		contentPane.add(BotonVender);
		
		BotonPublicaciones = new JButton("Mis Publicaciones");
		BotonPublicaciones.setBounds(26, 317, 139, 23);
		BotonPublicaciones.addActionListener(this);
		contentPane.add(BotonPublicaciones);
		
		BotonInfo = new JButton("Info. Productos");
		BotonInfo.setBounds(175, 283, 131, 23);
		BotonInfo.addActionListener(this);
		contentPane.add(BotonInfo);
		
		BotonMisCompras = new JButton("Mis Compras");
		BotonMisCompras.addActionListener(this);
		BotonMisCompras.setBounds(175, 317, 131, 23);
		contentPane.add(BotonMisCompras);
		
		BotonFiltrar = new JButton("Filtrar");
		BotonFiltrar.addActionListener(this);
		BotonFiltrar.setBounds(312, 317, 75, 23);
		contentPane.add(BotonFiltrar);
		
		
		JLabel lblNewLabel_2 = new JLabel(SistemaVentasImpl.usuarioActual);
		lblNewLabel_2.setBounds(105, 11, 139, 14);
		contentPane.add(lblNewLabel_2);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Juegos", "Hogar", "Electrodom\u00E9sticos", "Audio", "Autos"}));
		comboBox.setBounds(312, 283, 75, 22);
		contentPane.add(comboBox);
		filtroElegido = comboBox.getActionCommand();
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(26, 60, 361, 212);
		contentPane.add(scrollPane);
		
		tablaProductos = new JTable();
		
		model = new DefaultTableModel();
		tablaProductos.setModel(model);
		
		model.addColumn("ID");
		model.addColumn("Nombre");
		model.addColumn("Fecha");
		model.addColumn("Visto");

		scrollPane.setViewportView(tablaProductos);	
	}
	public void actionPerformed(ActionEvent e) {
		if(BotonVender == e.getSource()) {
			PublicarProducto PublicarProducto= new PublicarProducto();
			PublicarProducto.setVisible(true);
			PublicarProducto.setLocationRelativeTo(null);	
		}
		if(BotonFiltrar == e.getSource()){
			Filtrar filtrar= new Filtrar();
			filtrar.setVisible(true);
			filtrar.setLocationRelativeTo(null);
		}
	}
	public void llenarTabla(ListaProductos listaProductos) {
		NodoProductos nodoActual = listaProductos.getPrimero();
		Producto p = nodoActual.getProducto();
		for (int i = 0; i<listaProductos.hashCode();i++) {
			Object []fila = new Object[4];
			fila[0]= p.getId();;
			fila[1]= p.getNombre();
			fila[2]=  p.getFecha();
			fila[3]= p.getVisto();
			
			model.addRow(fila);
		
		}
		
	}
}
