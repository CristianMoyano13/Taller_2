package Dominio;


public class Compras {

}
