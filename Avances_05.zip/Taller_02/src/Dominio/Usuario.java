package Dominio;


public class Usuario {
	private String nomUsuario;
	private String nomCompleto;
	private String correo;
	private String contacto;
	private String contrase�a;
	
	public Usuario(String nomUsuario, String nomCompleto, String correo, String contacto, String contrase�a) {
		this.nomUsuario = nomUsuario;
		this.nomCompleto = nomCompleto;
		this.correo = correo;
		this.contacto = contacto;
		this.contrase�a = contrase�a;
	}

	public String getNomUsuario() {
		return nomUsuario;
	}

	public void setNomUsuario(String nomUsuario) {
		this.nomUsuario = nomUsuario;
	}

	public String getNomCompleto() {
		return nomCompleto;
	}

	public void setNomCompleto(String nomCompleto) {
		this.nomCompleto = nomCompleto;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getContacto() {
		return contacto;
	}

	public void setContacto(String contacto) {
		this.contacto = contacto;
	}

	public String getContrase�a() {
		return contrase�a;
	}

	public void setContrase�a(String contrase�a) {
		this.contrase�a = contrase�a;
	}
	
	
	
	
}
