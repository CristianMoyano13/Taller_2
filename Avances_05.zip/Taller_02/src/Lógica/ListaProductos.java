package L�gica;

import Dominio.NodoProductos;
import Dominio.Producto;

public class ListaProductos {
	private NodoProductos primero;
	
	public ListaProductos() {
		primero = null;
	}
	public void insertarPrimero(Producto p) {
		NodoProductos newNodo = new NodoProductos(p);
		newNodo.setSiguente(primero);
		primero = newNodo;
	}
	public boolean encontrar(int key) {
		NodoProductos nodoActual = primero;
		while(nodoActual != null && nodoActual.getProducto().getId() != key) {
			nodoActual = nodoActual.getSiguente();
		}
		if(nodoActual != null) {
			return true;
		}
		else {
			return false;
		}
	}
	public boolean eliminar(int key) {
		NodoProductos actual = primero;
		NodoProductos previo = primero;
		while(actual != null && actual.getProducto().getId() != key) {
			previo = actual;
			actual = actual.getSiguente();
		}
		if(actual != null) {
			if(actual == primero) {
				primero = primero.getSiguente();
			}
			else {
				previo.setSiguente(actual.getSiguente());
			}
			return true;
		}
		else {
			return false;
		}
	}
	public NodoProductos getPrimero() {
		return primero;
	}
}
