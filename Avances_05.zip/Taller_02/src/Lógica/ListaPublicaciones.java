package L�gica;
public class ListaPublicaciones {

}
