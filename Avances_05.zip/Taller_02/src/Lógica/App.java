package L�gica;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

public class App {
	public static void main(String[] args) throws NumberFormatException, IOException {
		SistemaVentas SistemaVentas = (SistemaVentas) new SistemaVentasImpl();
		Cargar_Usuarios(SistemaVentas);
		SistemaVentasImpl.iniciar_sesion();
	}
	public static void Cargar_Usuarios(L�gica.SistemaVentas sistema) throws NumberFormatException, FileNotFoundException{
		Scanner reader = new Scanner(new File("src/Usuarios.txt"));
        while(reader.hasNextLine()){
            String linea = reader.nextLine();
            String [] partes = linea.split(",");
            String nomUsuario = partes[0];
            String nomCompleto = partes[1];
            String correo = partes[2];
            String contacto = partes[3];
            String contrase�a = partes[4];
            sistema.agregarUsuario(nomUsuario, nomCompleto, correo, contacto, contrase�a);
        }
        reader.close();
	}
	
}


