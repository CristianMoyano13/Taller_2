package L�gica;

import Dominio.Usuario;
import gui.InicioSesion;

public class SistemaVentasImpl implements SistemaVentas {
	public static ListaUsuarios listaUsuarios;
	public static ListaProductos listaProductos;
	public static String usuarioActual = "";
	public static int posUsuarioActual = 0;
	
	public SistemaVentasImpl(){
		listaUsuarios = new ListaUsuarios(99999);
	}
	
	public void agregarUsuario(String nomUsuario, String nomCompleto, String correo, String contacto, String contrase�a) {
		Usuario u = new Usuario(nomUsuario,nomCompleto,correo,contacto,contrase�a);
		listaUsuarios.insertarUsuario(u);
	}
	
	
	
	static void iniciar_sesion() {
		InicioSesion inicio = new InicioSesion();
		inicio.setVisible(true);
		inicio.setLocationRelativeTo(null);
	}
}
