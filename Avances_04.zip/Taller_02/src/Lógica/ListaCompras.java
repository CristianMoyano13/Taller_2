package L�gica;
public class ListaCompras {

}
