package L�gica;

import Dominio.NodoProductos;

public class ListaProductos {
	private NodoProductos primero;
	
	public ListaProductos() {
		primero = null;
	}
	
	
	public void insertarPrimero(int dato1) {
		NodoProductos newNodo = new NodoProductos(dato1);
		newNodo.setSiguente(primero);
		primero = newNodo;
	}
	public boolean encontrar(int key) {
		NodoProductos nodoActual = primero;
		while(nodoActual != null && nodoActual.getDato() != key) {
			nodoActual = nodoActual.getSiguente();
		}
		if(nodoActual != null) {
			return true;
		}
		else {
			return false;
		}
	}
	public boolean eliminar(int key) {
		NodoProductos actual = primero;
		NodoProductos previo = primero;
		while(actual != null && actual.getDato() != key) {
			previo = actual;
			actual = actual.getSiguente();
		}
		if(actual != null) {
			if(actual == primero) {
				primero = primero.getSiguente();
			}
			else {
				previo.setSiguente(actual.getSiguente());
			}
			return true;
		}
		else {
			return false;
		}
	}
	public NodoProductos getPrimero() {
		return primero;
	}
	
	

}
