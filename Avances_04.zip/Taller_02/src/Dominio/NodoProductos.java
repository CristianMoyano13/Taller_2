package Dominio;

public class NodoProductos {
	private int dato;
	private NodoProductos siguente;
	
	public NodoProductos(int dato1) {
		this.dato = dato1;
		this.siguente = null;
	}

	public int getDato() {
		return dato;
	}

	public void setDato(int dato) {
		this.dato = dato;
	}

	public NodoProductos getSiguente() {
		return siguente;
	}

	public void setSiguente(NodoProductos siguente) {
		this.siguente = siguente;
	}
}
