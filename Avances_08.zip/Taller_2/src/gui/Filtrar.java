package gui;


import java.awt.event.ActionEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import Dominio.NodoProductos;
import Dominio.Producto;
import L�gica.ListaProductos;
import L�gica.SistemaVentasImpl;

public class Filtrar extends JFrame {
	private JPanel contentPane;
	private JTable tablaProductosFiltrados;
	JButton BotonVender,BotonPublicaciones,BotonInfo,BotonMisCompras,BotonFiltrar;
	private DefaultTableModel model;
	private JTable table;
	private JLabel txtFiltro;

	public Filtrar() {
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Lista de Productos Disponibles ");
		lblNewLabel.setBounds(20, 11, 198, 21);
		contentPane.add(lblNewLabel);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(20, 43, 390, 189);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		tablaProductosFiltrados = new JTable();
		
		model = new DefaultTableModel();
		tablaProductosFiltrados.setModel(model);
		
		model.addColumn("ID");
		model.addColumn("Nombre");
		model.addColumn("Fecha");
		model.addColumn("Visto");
		
		scrollPane.setViewportView(tablaProductosFiltrados);	
		
		txtFiltro = new JLabel(SistemaVentasImpl.filtroActual);
		txtFiltro.setBounds(217, 11, 125, 21);
		contentPane.add(txtFiltro);
	}
	public void llenarTabla(ListaProductos listaProductos) {
		NodoProductos nodoActual = listaProductos.getPrimero();
		Producto p = nodoActual.getProducto();
		for (int i = 0; i<listaProductos.hashCode();i++) {
			if(p.getCategoria().equals(SistemaVentasImpl.filtroActual)) {
				Object []fila = new Object[4];
				fila[0]= p.getId();;
				fila[1]= p.getNombre();
				fila[2]=  p.getFecha();
				fila[3]= p.getVisto();
				model.addRow(fila);
			}
		}
	}
}
