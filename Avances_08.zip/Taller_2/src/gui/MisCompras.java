package gui;
import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.AbstractListModel;
import java.awt.List;
public class MisCompras extends JFrame {
	private JPanel contentPane;
	private JTable tablaCompras;
	private DefaultTableModel model;
	public MisCompras() {
		setTitle("VentasCoquimbo - Mis Compras");
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		setBounds(100, 100, 423, 414);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Lista de compras");
		lblNewLabel.setBounds(31, 11, 185, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Cantidad de compras: ");
		lblNewLabel_1.setBounds(231, 11, 185, 14);
		contentPane.add(lblNewLabel_1);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(26, 60, 361, 212);
		contentPane.add(scrollPane);
		tablaCompras = new JTable();
		model = new DefaultTableModel();
		tablaCompras.setModel(model);
		model.addColumn("ID");
		model.addColumn("Usuario");
		model.addColumn("Nombre Producto");
		model.addColumn("Precio");
		scrollPane.setViewportView(tablaCompras);
	}
}
