package gui;
import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.AbstractListModel;
import javax.swing.JButton;

import java.awt.List;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
public class InfoProductos extends JFrame implements ActionListener {
	private JPanel contentPane;
	private JTable tablaProductos;
	JButton BotonComprar;
	private DefaultTableModel model;
	public InfoProductos() {
		setTitle("VentasCoquimbo - Informaci�n Productos");
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		setBounds(100, 100, 823, 414);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("<Nombre del producto>");
		lblNewLabel.setBounds(10, 11, 194, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("<Informaci�n del vendedor>");
		lblNewLabel_1.setBounds(160, 11, 194, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("<Nombre del vendedor>");
		lblNewLabel_2.setBounds(160, 31, 194, 14);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("<Contacto>");
		lblNewLabel_3.setBounds(410, 31, 194, 14);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Descripci�n");
		lblNewLabel_4.setBounds(10, 211, 194, 14);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("<Descripci�n>/n<Descripci�n>/n<Descripci�n>");
		lblNewLabel_5.setBounds(10, 231, 144, 14);
		contentPane.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("<Precio>");
		lblNewLabel_6.setBounds(10, 291, 194, 14);
		contentPane.add(lblNewLabel_6);
		
		BotonComprar = new JButton("Comprar");
		BotonComprar.setBounds(26, 331, 139, 23);
		BotonComprar.addActionListener(this);
		contentPane.add(BotonComprar);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(176, 60, 611, 212);
		contentPane.add(scrollPane);
		tablaProductos = new JTable();
		model = new DefaultTableModel();
		tablaProductos.setModel(model);
		model.addColumn("ID");
		model.addColumn("Fecha");
		model.addColumn("Nombre de usuario");
		scrollPane.setViewportView(tablaProductos);	
	}
	public void actionPerformed(ActionEvent e) {
	}
}
