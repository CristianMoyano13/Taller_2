package Dominio;

import java.io.File;

public class Publicacion extends Producto {
	private int precio;
	private String descripcion;
	private File foto;
	
	public Publicacion(int id, String nombre, String fecha, String visto, String categoria, int precio,	String descripcion, File foto) {
		super(id, nombre, fecha, visto, categoria);
		this.precio = precio;
		this.descripcion = descripcion;
		this.foto = foto;
	}

	public int getPrecio() {
		return precio;
	}
	public void setPrecio(int precio) {
		this.precio = precio;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public File getFoto() {
		return foto;
	}
	public void setFoto(File foto) {
		this.foto = foto;
	}
}
