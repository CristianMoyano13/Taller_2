package Dominio;

import java.sql.Date;

public class Producto {
	private int Id;
	private String Nombre;
	private String Fecha;
	private String Visto;
	private String Categoria;
	public Producto(int id, String nombre, String fecha, String visto, String categoria) {
		this.Id = id;
		this.Nombre = nombre;
		this.Fecha = fecha;
		this.Visto = visto;
		this.Categoria = categoria;
	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getNombre() {
		return Nombre;
	}
	public void setNombre(String nombre) {
		Nombre = nombre;
	}
	public String getFecha() {
		return Fecha;
	}
	public void setFecha(String fecha) {
		Fecha = fecha;
	}
	public String getVisto() {
		return Visto;
	}
	public void setVisto(String visto) {
		Visto = visto;
	}
	public String getCategoria() {
		return Categoria;
	}
	public void setCategoria(String categoria) {
		Categoria = categoria;
	}
	

	
	
	
	
	
	
	




}
