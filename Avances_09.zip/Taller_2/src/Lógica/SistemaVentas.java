package L�gica;
public interface  SistemaVentas {
	void agregarUsuario(String nomUsuario, String nomCompleto, String correo, String contacto, String contrase�a);
	
}
