package gui;

import java.awt.Image;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import Dominio.Producto;
import Dominio.Publicacion;
import L�gica.SistemaVentasImpl;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JOptionPane;
import java.awt.Choice;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import java.awt.event.ActionListener;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.event.ActionEvent;
import javax.swing.Icon;
import javax.swing.ImageIcon;

public class PublicarProducto extends JFrame implements ActionListener {

	private JPanel contentPane;
	private JTextField IngresarNombre;
	private JTextField IngresarPrecio;
	private JTextField IngresarDescripcion;
	private JLabel FotoPublicacion;
	private ImageIcon foto2;
	JButton SubirPublicacion, SubirFoto;
	Choice selector;
	JFileChooser jf;
	File foto;
	public static Choice Selector;
	
	public PublicarProducto() {	
		setTitle("VentasCoquimbo - Publicar Producto");
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		setBounds(100, 100, 449, 276);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Nombre");
		lblNewLabel.setBounds(10, 11, 46, 14);
		contentPane.add(lblNewLabel);
		
		IngresarNombre = new JTextField();
		IngresarNombre.setBounds(10, 27, 86, 20);
		contentPane.add(IngresarNombre);
		IngresarNombre.setColumns(10);
		
		JLabel lblCategoria = new JLabel("Categoria");
		lblCategoria.setBounds(121, 11, 73, 14);
		contentPane.add(lblCategoria);
		
		selector = new Choice();
		selector.addItem("Juegos");
		selector.addItem("Hogar");
		selector.addItem("Electrodomesticos");
		selector.addItem("Audio");
		selector.setBounds(121, 27, 80, 20);
		contentPane.add(selector);
		
		JLabel lblPrecio = new JLabel("Precio");
		lblPrecio.setBounds(10, 58, 46, 14);
		contentPane.add(lblPrecio);
		
		IngresarPrecio = new JTextField();
		IngresarPrecio.setColumns(10);
		IngresarPrecio.setBounds(10, 74, 86, 20);
		contentPane.add(IngresarPrecio);
		
		JLabel lblDescripcin = new JLabel("Descripci\u00F3n");
		lblDescripcin.setBounds(10, 105, 73, 14);
		contentPane.add(lblDescripcin);
		
		IngresarDescripcion = new JTextField();
		IngresarDescripcion.setColumns(10);
		IngresarDescripcion.setBounds(10, 122, 237, 65);
		contentPane.add(IngresarDescripcion);
		
		SubirPublicacion = new JButton("Registrar/Editar Publicaci\u00F3n");
		SubirPublicacion.addActionListener(this);
		SubirPublicacion.setBounds(20, 198, 214, 23);
		contentPane.add(SubirPublicacion);
		
		SubirFoto = new JButton("Subir Foto");
		SubirFoto.addActionListener(this);
		SubirFoto.setBounds(287, 198, 113, 23);
		contentPane.add(SubirFoto);
		
		FotoPublicacion = new JLabel("New label");
		FotoPublicacion.setIcon(new ImageIcon(PublicarProducto.class.getResource("/Imagenes/ImagenSubir.png")));
		FotoPublicacion.setBounds(257, 21, 166, 166);
		contentPane.add(FotoPublicacion);
		
		setResizable(false);
		FotoPublicacion.setSize(166,166);
		setLocationRelativeTo(null);
		setResizable(false);
		foto2 = new ImageIcon("src/Imagenes/ImagenSubir.png");
		Icon icono = new ImageIcon(foto2.getImage().getScaledInstance(FotoPublicacion.getWidth(),FotoPublicacion.getHeight(),Image.SCALE_DEFAULT));
		FotoPublicacion.setIcon(icono);
		this.repaint();
	}
	public void actionPerformed(ActionEvent e) {
		if(SubirFoto == e.getSource()) {
			jf = new JFileChooser();
			File foto = jf.getSelectedFile();
			jf.setMultiSelectionEnabled(false);
			if(jf.showOpenDialog(this) ==  JFileChooser.APPROVE_OPTION) {
				ImageIcon foto2 = new ImageIcon(jf.getSelectedFile().toString());
				FotoPublicacion.setIcon(foto2);
			}
		}
		if(SubirPublicacion == e.getSource() && selector == e.getSource() && !IngresarNombre.equals("") && !IngresarPrecio.equals("")) {
			if(selector.getSelectedItem().equals("Juegos")) {
				String categoriaProducto = "Juegos";
				String nombProducto = IngresarNombre.getText();
				int precioProducto = Integer.parseInt(IngresarPrecio.getText());
				String descripcionProducto = IngresarDescripcion.getText();
				String fechaPublicacion = fechaActual() ;
				int id = 0;
				String vistoProducto = "No";
				Producto p = new Publicacion(id, nombProducto, fechaPublicacion, vistoProducto, categoriaProducto, precioProducto, descripcionProducto, foto);
				SistemaVentasImpl.listaProductos.insertarPrimero(p);
				id++;
			}
			else if(selector.getSelectedItem().equals("Hogar")) {
				String categoriaProducto = "Hogar";
				String nombProducto = IngresarNombre.getText();
				int precioProducto = Integer.parseInt(IngresarPrecio.getText());
				String descripcionProducto = IngresarDescripcion.getText();
				String fechaPublicacion = fechaActual() ;
				int id= 0;
				String vistoProducto = "No";
				Producto p = new Publicacion(id, nombProducto, fechaPublicacion, vistoProducto, categoriaProducto, precioProducto, descripcionProducto, foto);
				SistemaVentasImpl.listaProductos.insertarPrimero(p);
				id++;
			}
			else if(selector.getSelectedItem().equals("Electrodomesticos")) {
				String categoriaProducto = "Electrodomesticos";
				String nombProducto = IngresarNombre.getText();
				int precioProducto = Integer.parseInt(IngresarPrecio.getText());
				String descripcionProducto = IngresarDescripcion.getText();
				String fechaPublicacion = fechaActual() ;
				int id= 0;
				String vistoProducto = "No";
				Producto p = new Publicacion(id, nombProducto, fechaPublicacion, vistoProducto, categoriaProducto, precioProducto, descripcionProducto, foto);
				SistemaVentasImpl.listaProductos.insertarPrimero(p);
				id++;
			}
			else if(selector.getSelectedItem().equals("Audio")) {
				String categoriaProducto = "Audio";
				String nombProducto = IngresarNombre.getText();
				int precioProducto = Integer.parseInt(IngresarPrecio.getText());
				String descripcionProducto = IngresarDescripcion.getText();
				String fechaPublicacion = fechaActual() ;
				int id= 0;
				String vistoProducto = "No";
				Producto p = new Publicacion(id, nombProducto, fechaPublicacion, vistoProducto, categoriaProducto, precioProducto, descripcionProducto, foto);
				SistemaVentasImpl.listaProductos.insertarPrimero(p);
				id++;
			}
			else {
				JOptionPane.showMessageDialog(null,"Seleccione la categoria del producto");
			}
		Perfil perfil = new Perfil();
		perfil.setVisible(true);
		perfil.setLocationRelativeTo(null);
		}
		else {
			JOptionPane.showMessageDialog(null,"Rellene los campos para publicar");
		}
	}
	public static String fechaActual() {
		Date fecha = new Date();
		SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/YY");
		return formatoFecha.format(fecha);
	}
}
