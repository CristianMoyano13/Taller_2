package gui;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import L�gica.ListaProductos;
import L�gica.SistemaVentasImpl;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Registro extends JFrame implements ActionListener{
	private JPanel contentPane;
	private JTextField IngresarNomUsuario;
	private JTextField IngresarCorreo;
	private JTextField IngresarContra1;
	private JTextField IngresarNomCompl;
	private JTextField IngresarContacto;
	private JTextField IngresarContra2;
	JButton BotonRegistrarse;
	
	public Registro() {
		setTitle("VentasCoquimbo - Registro");
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Nombre de Usuario");
		lblNewLabel.setBounds(52, 35, 110, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblCorreo = new JLabel("Correo");
		lblCorreo.setBounds(52, 95, 110, 14);
		contentPane.add(lblCorreo);
		
		JLabel lblContrasea = new JLabel("Contrase\u00F1a");
		lblContrasea.setBounds(52, 163, 110, 14);
		contentPane.add(lblContrasea);
		
		IngresarNomUsuario = new JTextField();
		IngresarNomUsuario.setBounds(52, 53, 110, 20);
		contentPane.add(IngresarNomUsuario);
		IngresarNomUsuario.setColumns(10);
		
		IngresarCorreo = new JTextField();
		IngresarCorreo.setColumns(10);
		IngresarCorreo.setBounds(52, 111, 110, 20);
		contentPane.add(IngresarCorreo);
		
		JLabel lblNombreCompleto = new JLabel("Nombre Completo");
		lblNombreCompleto.setBounds(255, 35, 145, 14);
		contentPane.add(lblNombreCompleto);
		
		JLabel contacto = new JLabel("Contacto");
		contacto.setBounds(255, 95, 145, 14);
		contentPane.add(contacto);
		
		JLabel lblConfirmarContrasea = new JLabel("Confirmar Contrase\u00F1a");
		lblConfirmarContrasea.setBounds(255, 163, 156, 14);
		contentPane.add(lblConfirmarContrasea);
		
		IngresarNomCompl = new JTextField();
		IngresarNomCompl.setColumns(10);
		IngresarNomCompl.setBounds(255, 53, 110, 20);
		contentPane.add(IngresarNomCompl);
		
		IngresarContacto = new JTextField();
		IngresarContacto.setColumns(10);
		IngresarContacto.setBounds(255, 111, 110, 20);
		contentPane.add(IngresarContacto);
		
		IngresarContra1 = new JTextField();
		IngresarContra1.setColumns(10);
		IngresarContra1.setBounds(52, 181, 110, 20);
		contentPane.add(IngresarContra1);
		
		IngresarContra2 = new JTextField();
		IngresarContra2.setColumns(10);
		IngresarContra2.setBounds(255, 181, 110, 20);
		contentPane.add(IngresarContra2);
		
		BotonRegistrarse = new JButton("Registrarse");
		BotonRegistrarse.setBounds(155, 213, 110, 23);
		BotonRegistrarse.addActionListener(this);
		contentPane.add(BotonRegistrarse);
	}

	public void actionPerformed(ActionEvent e) {
		String nomUsuario = IngresarNomUsuario.getText();
		String nombCompleto = IngresarNomCompl.getText();
		String correo = IngresarCorreo.getText();
		String contacto = IngresarContacto.getText();
		String contra1 = IngresarContra1.getText();
		String contra2 = IngresarContra2.getText();
		if(BotonRegistrarse == e.getSource()) {
			if(contra1.equals("") && contra2.equals("")) {
				JOptionPane.showMessageDialog(null,"Usuario NO registrado, contrase�a inv�lida");
			}
			else if(contra1.equals(contra2)) {
				SistemaVentasImpl.usuarioActual = nomUsuario;
				SistemaVentasImpl.posUsuarioActual = SistemaVentasImpl.listaUsuarios.posicionCliente(nomUsuario);
				JOptionPane.showMessageDialog(null,"Usuario Registrado");
				Perfil perfil = new Perfil();
				perfil.setVisible(true);
				perfil.setLocationRelativeTo(null);
				SistemaVentasImpl.usuarioActual = nomUsuario;
				ListaProductos ListaProductos = new ListaProductos() ;
				perfil.llenarTablaPerfil(ListaProductos);
				SistemaVentasImpl.usuarioActual = nomUsuario;
			}
			else {
				JOptionPane.showMessageDialog(null,"Usuario NO registrado, confirme contrase�as");
			}
		}
	}
}
