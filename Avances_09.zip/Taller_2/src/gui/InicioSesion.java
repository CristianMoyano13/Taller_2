package gui;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import Dominio.Usuario;
import L�gica.App;
import L�gica.ListaProductos;
import L�gica.ListaUsuarios;
import L�gica.SistemaVentasImpl;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class InicioSesion extends JFrame implements ActionListener{
	private JPanel contentPane;
	private JTextField IngresarUsuario;
	private JTextField IngresarPassword;
	JButton BotonRegistrate, BotonIngresar;

	public InicioSesion() {
		setTitle("VentasCoquimbo - Login");
		setDefaultCloseOperation(HIDE_ON_CLOSE);
		setBounds(100, 100, 345, 305);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblTitulo = new JLabel("Usuario");
		lblTitulo.setBounds(75, 25, 51, 22);
		contentPane.add(lblTitulo);
		
		IngresarUsuario = new JTextField();
		IngresarUsuario.setBounds(75, 46, 130, 20);
		contentPane.add(IngresarUsuario);
		IngresarUsuario.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Contrase\u00F1a");
		lblNewLabel.setBounds(75, 77, 86, 22);
		contentPane.add(lblNewLabel);
		
		IngresarPassword = new JTextField();
		IngresarPassword.setBounds(75, 102, 130, 22);
		contentPane.add(IngresarPassword);
		IngresarPassword.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("No tienes una cuenta?");
		lblNewLabel_1.setBounds(57, 135, 138, 22);
		contentPane.add(lblNewLabel_1);
		
		BotonRegistrate = new JButton("Reg\u00EDstrate");
		BotonRegistrate.setBounds(188, 135, 105, 22);
		BotonRegistrate.addActionListener(this);
		contentPane.add(BotonRegistrate);
		
		BotonIngresar = new JButton("Ingresar");
		BotonIngresar.setBounds(106, 168, 89, 23);
		BotonIngresar.addActionListener(this);
		contentPane.add(BotonIngresar);
	}
	public void actionPerformed(ActionEvent e) {
		if(BotonIngresar == e.getSource()) {
			String nomUsuario = IngresarUsuario.getText();
			String password = IngresarPassword.getText();
			SistemaVentasImpl.usuarioActual = nomUsuario;
			SistemaVentasImpl.posUsuarioActual = SistemaVentasImpl.listaUsuarios.posicionCliente(nomUsuario);
			Usuario u = SistemaVentasImpl.listaUsuarios.buscarNombre(nomUsuario);
			int posicion = SistemaVentasImpl.listaUsuarios.posicionCliente(nomUsuario);
			if(nomUsuario.equals(u.getNomUsuario()) && password.equals(u.getContrase�a())){
				JOptionPane.showMessageDialog(null,"Usuario encontrado");
				Perfil perfil = new Perfil();
				perfil.setVisible(true);
				perfil.setLocationRelativeTo(null);
				SistemaVentasImpl.posUsuarioActual = posicion;
				SistemaVentasImpl.usuarioActual = nomUsuario;
				ListaProductos ListaProductos = new ListaProductos();
				perfil.llenarTablaPerfil(ListaProductos);
			}
			else if(!nomUsuario.equals(u.getNomUsuario()) && !password.equals(u.getContrase�a())) {
				JOptionPane.showMessageDialog(null,"Usuario no encontrado, Vuelva a intentar o registrese");
			}
			else if(nomUsuario.equals("") || !password.equals("")) {
				JOptionPane.showMessageDialog(null,"Campos vac�os, Vuelva a intentar o registrese");
			}
			else {
			JOptionPane.showMessageDialog(null,"Usuario no encontrado, Vuelva a intentar o registrese");
			}
		}
		if(BotonRegistrate == e.getSource()) {
			Registro registro = new Registro();
			registro.setVisible(true);
			registro.setLocationRelativeTo(null);	
		}
	}
}
		
	

