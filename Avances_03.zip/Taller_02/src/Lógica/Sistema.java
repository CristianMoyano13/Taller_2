package L�gica;
public interface  Sistema {

}
