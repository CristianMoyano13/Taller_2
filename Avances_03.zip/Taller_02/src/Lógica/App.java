package L�gica;


import java.io.File;
import java.io.IOException;
import java.util.Scanner;

import Dominio.Usuario;
import gui.InicioSesion;
import gui.Perfil;

public class App {
	public static ListaUsuarios listaUsuarios;
	public static String usuarioActual = "CRIS";
	public static int posUsuarioActual = 0;
	
	public static void main(String[] args) throws NumberFormatException, IOException {
		listaUsuarios = new ListaUsuarios(1000);
		Cargar_Usuarios();
		iniciar_sesion();
		perfil();
		publicarProducto();
		filtrar();
	}
	public static boolean agregarUsuario(String nomUsuario, String nomCompleto, String correo, String contacto, String contrase�a) {
		Usuario u = new Usuario(nomUsuario,nomCompleto,correo,contacto,contrase�a);
		boolean ingreso = listaUsuarios.insertarUsuario(u);
		return ingreso;
	}
	public static void Cargar_Usuarios() throws NumberFormatException, IOException{
		Scanner reader = new Scanner(new File("src/Usuarios.txt"));
        while(reader.hasNextLine()){
            String linea = reader.nextLine();
            String [] partes = linea.split(",");
            String nomUsuario = partes[0];
            String nomCompleto = partes[1];
            String correo = partes[2];
            String contacto = partes[3];
            String contrase�a = partes[4];
            agregarUsuario(nomUsuario,nomCompleto,correo,contacto,contrase�a);
        }
        reader.close();
	}
	
	
	private static void iniciar_sesion() {
		InicioSesion inicio = new InicioSesion();
		inicio.setVisible(true);
		inicio.setLocationRelativeTo(null);
	}
	private static void perfil() {
	}
	private static void filtrar() {
	}
	private static void publicarProducto() {
	}
	
}


