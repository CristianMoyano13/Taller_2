package L�gica;

public class SistemaImpl implements Sistema {

	
}
