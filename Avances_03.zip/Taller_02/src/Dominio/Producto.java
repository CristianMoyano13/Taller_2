package Dominio;


public class Producto {

}
