package Dominio;


public class Publicacion {

}
