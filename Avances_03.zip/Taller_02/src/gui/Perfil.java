package gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import L�gica.App;
import L�gica.ListaUsuarios;

import javax.swing.JLabel;
import javax.swing.JList;
import java.awt.Choice;
import java.awt.List;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.ScrollPane;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JToolBar;
import javax.swing.JSlider;
import javax.swing.JMenuBar;
import javax.swing.table.DefaultTableModel;
import java.awt.Color;
import javax.swing.AbstractListModel;
import javax.swing.JScrollBar;

public class Perfil extends JFrame implements ActionListener{
	public static String filtroElegido;
	private JPanel contentPane;
	private JTable table;
	JButton BotonVender,BotonPublicaciones,BotonInfo,BotonMisCompras,BotonFiltrar;

	public Perfil() {
		setTitle("VentasCoquimbo - Perfil");
		setDefaultCloseOperation(HIDE_ON_CLOSE);
		setBounds(100, 100, 446, 394);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		JLabel lblNewLabel = new JLabel("Bienvenido ");
		lblNewLabel.setBounds(38, 11, 85, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Lista de productos disponilbes");
		lblNewLabel_1.setBounds(48, 36, 227, 14);
		contentPane.add(lblNewLabel_1);
		
		BotonVender = new JButton("Vender producto");
		BotonVender.setBounds(26, 283, 139, 23);
		BotonVender.addActionListener(this);
		contentPane.add(BotonVender);
		
		BotonPublicaciones = new JButton("Mis Publicaciones");
		BotonPublicaciones.setBounds(26, 317, 139, 23);
		BotonPublicaciones.addActionListener(this);
		contentPane.add(BotonPublicaciones);
		
		BotonInfo = new JButton("Info. Productos");
		BotonInfo.setBounds(175, 283, 131, 23);
		BotonInfo.addActionListener(this);
		contentPane.add(BotonInfo);
		
		BotonMisCompras = new JButton("Mis Compras");
		BotonMisCompras.addActionListener(this);
		BotonMisCompras.setBounds(175, 317, 131, 23);
		contentPane.add(BotonMisCompras);
		
		BotonFiltrar = new JButton("Filtrar");
		BotonFiltrar.addActionListener(this);
		BotonFiltrar.setBounds(312, 317, 75, 23);
		contentPane.add(BotonFiltrar);
		
		
		String nombreUsuario = App.listaUsuarios.getUsuarioI(App.posUsuarioActual).getNomUsuario();
		JLabel lblNewLabel_2 = new JLabel(nombreUsuario);
		lblNewLabel_2.setBounds(105, 11, 139, 14);
		contentPane.add(lblNewLabel_2);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Juegos", "Hogar", "Electrodom\u00E9sticos", "Audio", "Autos"}));
		comboBox.setBounds(312, 283, 75, 22);
		contentPane.add(comboBox);
		filtroElegido = comboBox.getActionCommand();
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
			},
			new String[] {
				"New column", "New column", "New column", "New column"
			}
		));
		table.setBounds(26, 93, 361, 160);
		contentPane.add(table);
		
		JLabel IndiceID = new JLabel("ID");
		IndiceID.setBounds(32, 76, 32, 14);
		contentPane.add(IndiceID);
		
		JLabel IndiceNombre = new JLabel("Nombre");
		IndiceNombre.setBounds(123, 76, 64, 14);
		contentPane.add(IndiceNombre);
		
		JLabel IndiceFecha = new JLabel("Fecha");
		IndiceFecha.setBounds(207, 76, 75, 14);
		contentPane.add(IndiceFecha);
		
		JLabel IndiceVisto = new JLabel("Visto");
		IndiceVisto.setBounds(301, 76, 85, 14);
		contentPane.add(IndiceVisto);
	}
		
	public void actionPerformed(ActionEvent e) {
		if(BotonVender == e.getSource()) {
			PublicarProducto PublicarProducto= new PublicarProducto();
			PublicarProducto.setVisible(true);
			PublicarProducto.setLocationRelativeTo(null);	
		}
		if(BotonFiltrar == e.getSource()){
			Filtrar filtrar= new Filtrar();
			filtrar.setVisible(true);
			filtrar.setLocationRelativeTo(null);
		}
		
		
	}
}
