package gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JSpinner;
import javax.swing.JList;
import java.awt.Choice;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class PublicarProducto extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;

	
	public PublicarProducto() {
		setTitle("VentasCoquimbo - Publicar Producto");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 449, 276);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Nombre");
		lblNewLabel.setBounds(10, 11, 46, 14);
		contentPane.add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(10, 27, 86, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblCategoria = new JLabel("Categoria");
		lblCategoria.setBounds(121, 11, 73, 14);
		contentPane.add(lblCategoria);
		
		Choice choice = new Choice();
		choice.setBounds(121, 27, 80, 20);
		contentPane.add(choice);
		
		JLabel lblPrecio = new JLabel("Precio");
		lblPrecio.setBounds(10, 58, 46, 14);
		contentPane.add(lblPrecio);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(10, 74, 86, 20);
		contentPane.add(textField_1);
		
		JLabel lblDescripcin = new JLabel("Descripci\u00F3n");
		lblDescripcin.setBounds(10, 105, 73, 14);
		contentPane.add(lblDescripcin);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(10, 122, 237, 65);
		contentPane.add(textField_2);
		
		JButton btnNewButton = new JButton("Registrar/Editar Publicaci\u00F3n");
		btnNewButton.setBounds(20, 198, 214, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Subir Foto");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_1.setBounds(287, 198, 113, 23);
		contentPane.add(btnNewButton_1);
		
		textField_3 = new JTextField();
		textField_3.setBounds(260, 27, 164, 160);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
	}

}
